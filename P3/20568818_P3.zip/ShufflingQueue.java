public class ShufflingQueue extends DSAQueue
{
	
	public ShufflingQueue()
	{
		super();
	}

	public ShufflingQueue(int maxCapacity)
	{
		super();
	}

	
}
